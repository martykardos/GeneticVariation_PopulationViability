repNum <- 13 
library(quantPop)
genVarMat <- NULL
genLoadMat <- NULL
piMat <- NULL
lethalEqMat <- NULL
homLoadMat <- NULL
fitMat <- NULL
for(i in 1:2){
  tryCatch({
  logQuant_mut_delMut(burnin=1,
                      gens=1000,
                      genSize=10000000,
                      chroms=38,
                      phen0=0,
                      phenOpt=rep(0,1000),
                      c=6,
                      mu=7.35e-9,
                      quantDom = FALSE,
                      muOff=1100,
                      minSize=-0.5,
                      maxSize=0.5,
                      N=c(rep(1000,900),rep(25,100)),
                      Ve=4,
                      hardSelecGen=1201,
                      K=1000,
                      lambda=1.5,
                      f=4,
                      delMutation=TRUE,
                      delMu=6e-8,
                      propLethal=0.05,
                      delMuGammaShape=0.5,
                      delMuGammaScale=0.1,
                      neutMutation=TRUE,
                      neutMu=2.4e-9,
                      Beta=13,
                      importGenos=FALSE,
                      importGenoIndivs=NULL,
                      mutationTag=NULL,
                      genoMat1Name=NULL,
                      genoMat2Name=NULL,
                      locusInfoName=NULL,
                      genRescue=FALSE,
                      rescueInGenos1=NULL,
                      rescueInGenos2=NULL,
                      rescueLocusInfo=NULL,
                      rescueN=NULL,
                      rescueGens=NULL)
  genVarMat <- rbind(genVarMat,addVar)
  genLoadMat <- rbind(genLoadMat,genLoad)
  piMat <- rbind(piMat,piVec)
  lethalEqMat <- rbind(lethalEqMat,lethalEqs)
  homLoadMat <- rbind(homLoadMat,homLoad)
  fitMat <- rbind(fitMat,fitMean)
  }, error=function(e){})
}
   write.table(homLoadMat,file=paste("homLoad_btlnk_lethals_",repNum,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(lethalEqMat,file=paste("lethalEqs_btlnk_lethals_",repNum,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
             write.table(piMat,file=paste("pi_btlnk_lethals_",repNum,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
   write.table(genLoadMat,file=paste("genLoad_btlnk_lethals_",repNum,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
     write.table(genVarMat,file=paste("genVar_btlnk_lethals_",repNum,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
       write.table(fitMat,file=paste("meanFit_btlnk_lethals_",repNum,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)

