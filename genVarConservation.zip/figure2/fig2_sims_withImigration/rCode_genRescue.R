#######################################################################
# test genetic rescue simulation workflow (h2 ~0.6)
#######################################################################
setwd("~/Documents/dominance_genRescue/geneticRescue")

library(quantPop)
#-----------------------------------------
# simulate a big source population
#-----------------------------------------
logQuant_mut_delMut(burnin=1,
                    gens=900,
                    genSize=10000000,
                    chroms=38,
                    phen0=0,
                    phenOpt=rep(0,1000),
                    c=6,
                    mu=7.35e-9,
                    quantDom = FALSE,
                    muOff=1100,
                    minSize=-0.5,
                    maxSize=0.5,
                    N=rep(1000,1000),
                    Ve=4,
                    hardSelecGen=1001,
                    K=1000,
                    lambda=1.5,
                    f=4,
                    delMutation=TRUE,
                    delMu=6e-8,
                    propLethal=0.05,
                    delMuGammaShape=0.5,
                    delMuGammaScale=0.1,
                    neutMutation=TRUE,
                    neutMu=2.4e-9,
                    Beta=13,
                    importGenos=FALSE,
                    importGenoIndivs=NULL,
                    mutationTag=NULL,
                    genoMat1Name=NULL,
                    genoMat2Name=NULL,
                    locusInfoName=NULL,
                    genRescue=FALSE,
                    rescueInGenos1=NULL,
                    rescueInGenos2=NULL,
                    rescueLocusInfo=NULL,
                    rescueN=NULL,
                    rescueGens=NULL)

write.table(polyInfo,file="sourcePopPolyInfo",quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(genoMat1,file="sourcePop_gens1",quote=FALSE,row.names=FALSE,col.names=TRUE)
write.table(genoMat2,file="sourcePop_gens2",quote=FALSE,row.names=FALSE,col.names=TRUE)
h2Vec <- addVar/phenVar
write.table(h2Vec,file="sourcePop_h2Vec",quote=FALSE,row.names=FALSE,col.names=TRUE)
write.table(numSegVec,file="sourcePop_numSegVec",quote=FALSE,row.names=FALSE,col.names=TRUE)
write.table(genLoad,file="sourcePop_genLoadVec",quote=FALSE,row.names=FALSE,col.names=TRUE)
write.table(homLoad,file="sourcePop_homLoadVec",quote=FALSE,row.names=FALSE,col.names=TRUE)
write.table(addVar,file="sourcePop_addVarVec",quote=FALSE,row.names=FALSE,col.names=TRUE)


###########################################################
# simulation the population where the immigrants actually
# come from
###########################################################

runTime <- 100
grabInds <- sort(sample(1:1000,500,replace=FALSE))
library(quantPop)
logQuant_mut_delMut(burnin=1,
                    gens=runTime,
                    genSize=10000000,
                    chroms=38,
                    phen0=0,
                    phenOpt=rep(0,runTime),
                    c=6,
                    mu=7.35e-9,
                    quantDom= TRUE,
                    muOff=runTime,
                    minSize=-0.5,
                    maxSize=0.5,
                    N=rep(500,200),
                    Ve=4,
                    hardSelecGen=runTime + 10,
                    K=100,
                    lambda=2.5,
                    f=4,
                    delMutation=TRUE,
                    delMu=6e-8,
                    propLethal=0.05,
                    delMuGammaShape=0.5,
                    delMuGammaScale=0.1,
                    neutMutation=TRUE,
                    neutMu=2.4e-8,
                    Beta=13,
                    importGenos=TRUE,
                    importGenoIndivs=grabInds,
                    mutationTag="A",
                    genoMat1Name="sourcePop_gens1",
                    genoMat2Name="sourcePop_gens2",
                    locusInfoName="sourcePopPolyInfo",
                    genRescue=FALSE,
                    rescueInGenos1=NULL,
                    rescueInGenos2=NULL,
                    rescueLocusInfo=NULL,
                    rescueN=NULL,
                    rescueGens=NULL)

write.table(polyInfo,file="rescuePopPolyInfo",quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(genoMat1,file="rescuePop_gens1",quote=FALSE,row.names=FALSE,col.names=TRUE)
write.table(genoMat2,file="rescuePop_gens2",quote=FALSE,row.names=FALSE,col.names=TRUE)


###########################################################
# genetic rescue population
###########################################################
homLoadMat <- NULL
genLoadMat <- NULL
NMat <- NULL
lethalEqMat <- NULL
piMat <- NULL
vaMat <- NULL
addVarMat <- NULL
reps <- 50

numSegMat <- NULL
repIter <- 0
while(repIter < 50){
    #-----------------------------------------
    # simulate the rescue population
    #-----------------------------------------
    runTime <- 100
    fitFunSd <- 6
    grabInds2 <- sort(sample((1:1000)[-grabInds],25,replace=FALSE))
    library(quantPop)
    logQuant_mut_delMut(burnin=1,
                        gens=runTime,
                        genSize=10000000,
                        chroms=38,
                        phen0=0,
                        phenOpt=rep(0,runTime),
                        c=6,
                        mu=7.35e-9,
                        quantDom= TRUE,
                        muOff=runTime,
                        minSize=-0.5,
                        maxSize=0.5,
                        N=rep(25,200),
                        Ve=4,
                        hardSelecGen=runTime + 10,
                        K=100,
                        lambda=2.5,
                        f=4,
                        delMutation=TRUE,
                        delMu=6e-8,
                        propLethal=0.05,
                        delMuGammaShape=0.5,
                        delMuGammaScale=0.1,
                        neutMutation=TRUE,
                        neutMu=2.4e-8,
                        Beta=13,
                        importGenos=TRUE,
                        importGenoIndivs=grabInds2,
                        mutationTag="B",
                        genoMat1Name="sourcePop_gens1",
                        genoMat2Name="sourcePop_gens2",
                        locusInfoName="sourcePopPolyInfo",
                        genRescue=TRUE,
                        rescueInGenos1="rescuePop_gens1",
                        rescueInGenos2="rescuePop_gens2",
                        rescueLocusInfo="rescuePopPolyInfo",
                        rescueN=5,
                        rescueGens=seq(2,50,2))
  homLoadMat <- rbind(homLoadMat,homLoad)
  genLoadMat <- rbind(genLoadMat,genLoad)
  NMat <- rbind(NMat,NVec)
  lethalEqMat <- rbind(lethalEqMat,lethalEqs)
  piMat <- rbind(piMat,piVec)
  vaMat <- rbind(vaMat,addVar)
  addVarMat <- rbind(addVarMat,addVar)
  numSegMat <- rbind(numSegMat,numSegVec)
  repIter <- nrow(lethalEqMat)
}

write.table(homLoadMat,file="homLoad_genRescue",quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(genLoadMat,file="genLoad_genRescue",quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(lethalEqMat,file="lethalEq_genRescue",quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(piMat,file="pi_genRescue",quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(addVarMat,file="addVar_genRescue",quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(numSegMat,file="numSeg_genRescue",quote=FALSE,row.names=FALSE,col.names=FALSE)





################################################
# plot results
################################################


# grab the data

lethalEq1 <- read.table("lethalEq_genRescue")
pi1 <- read.table("pi_genRescue")
genLoad1 <- read.table("genLoad_genRescue")
genVar1 <- read.table("addVar_genRescue")
homLoad1 <- read.table("homLoad_genRescue")



library(scales)
par(mfrow=c(2,2),mar=c(4,6,2,2))

############################
#########pi
############################
plot(c(1,50),c(1.0e-5,max(pi1,na.rm=TRUE)),type="n",xlab="Generation",ylab=expression(pi),cex.lab=1.5)


############# small source population
for(i in 1:nrow(pi1)){
  lines(1:101,pi1[i,],col=alpha("orange",alpha=0.25))
}
pi1Means <- colMeans(pi1[,],na.rm=TRUE)
lines(1:101,pi1Means,lwd=4,col="orange")
par(xpd=TRUE)
text(x=-35,y=3.8,labels="A",cex=1.5,font=2)
par(xpd=FALSE)



#############################
######### lethal equivalents
#############################
plot(c(1,50),c(0.4,max(lethalEq1,na.rm=TRUE)),type="n",xlab="Generation",ylab="Lethal equivalents",cex.lab=1.5)



############# small source population
for(i in 1:nrow(lethalEq1)){
  lines(1:100,lethalEq1[i,],col=alpha("orange",alpha=0.1))
}
lethalEq1Means <- colMeans(lethalEq1[,],na.rm=TRUE)
lines(1:100,lethalEq1Means,lwd=4,col="orange")


############################
######### drift load
############################
plot(c(1,50),c(0,max(homLoad1,na.rm=TRUE)),type="n",xlab="Generation",ylab="Drift load",cex.lab=1.5)


############# small source population
for(i in 1:nrow(genVar1)){
  lines(1:100,homLoad1[i,],col=alpha("orange",alpha=0.1))
}
homLoad1Means <- colMeans(homLoad1,na.rm=TRUE)
lines(1:100,homLoad1Means,lwd=4,col="orange")


############################
######### additive variance
############################
plot(c(1,50),c(1.0e-5,max(genVar1,na.rm=TRUE)),type="n",xlab="Generation",ylab=expression(italic(""*V*"")[a]),cex.lab=1.5)


############# small source population
for(i in 1:nrow(genVar1)){
  lines(1:100,genVar1[i,],col=alpha("orange",alpha=0.1))
}
genVar1Means <- colMeans(genVar1[,],na.rm=TRUE)
lines(1:100,genVar1Means,lwd=4,col="orange")



