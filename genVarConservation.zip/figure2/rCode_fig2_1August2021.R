#######################################################################################################
# make a figure showing nucleotide diversity, lethal equivalents, drift load, and additive variance
# through time, with and without immigration
#######################################################################################################

# grab the data with no immigration
lethalEqsFinal <- NULL
piFinal <- NULL
genLoadFinal <- NULL
genVarFinal <- NULL
homLoadFinal <- NULL
fit <- NULL
library(scales)
for(i in 1:25){
  setwd(paste("~/Documents/dominance_genRescue/btlnk_smallNe/reps",i,sep=""))
  lethalEqsFinal <- rbind(lethalEqsFinal,read.table(paste("lethalEqs_btlnk_lethals_",i,sep="")))
  piFinal <- rbind(piFinal,read.table(paste("pi_btlnk_lethals_",i,sep="")))
  genLoadFinal <- rbind(genLoadFinal,read.table(paste("genLoad_btlnk_lethals_",i,sep="")))
  genVarFinal <- rbind(genVarFinal,read.table(paste("genVar_btlnk_lethals_",i,sep="")))
  homLoadFinal <- rbind(homLoadFinal,read.table(paste("homLoad_btlnk_lethals_",i,sep="")))
  fit <- rbind(fit,read.table(paste("meanFit_btlnk_lethals_",i,sep="")))
}



#################################################################################
# figure with immigration scenario
#################################################################################

setwd("~/Documents/dominance_genRescue/geneticRescue")
# grab the data

lethalEq1 <- read.table("lethalEq_genRescue")
pi1 <- read.table("pi_genRescue")
genLoad1 <- read.table("genLoad_genRescue")
genVar1 <- read.table("addVar_genRescue")
homLoad1 <- read.table("homLoad_genRescue")



library(scales)
par(mfrow=c(2,2),mar=c(4,6,2,2))

########################################
############### nucleotide diversity
########################################
plot(c(1,100),c(0.5,3.5),type="n",xlab="Generation",ylab=expression(paste(pi," x 10"^4,sep="")),cex.lab=1.5)
for(i in 1:25){
  lines(1:100,piFinal[i,901:1000]*10e4,col=alpha("orange",alpha=0.2))
}
piMeans <- colMeans(piFinal[1:25,901:1000]*10e4)
lines(1:100,piMeans,lwd=4,col="darkorange")
par(xpd=TRUE)
text(x=-35,y=3.5,labels="A",cex=1.5,font=2)
par(xpd=FALSE)
############# small source population
for(i in 1:nrow(pi1)){
  lines(1:100,pi1[i,2:101]*10e4,col=alpha("blue",alpha=0.1))
}
pi1Means <- colMeans(pi1[,2:101]*10e4,na.rm=TRUE)
lines(1:100,pi1Means,lwd=4,col=alpha("darkblue",alpha=0.8))


#############################
######### lethal equivalents
#############################
plot(c(1,100),c(0,3.5),type="n",xlab="Generation",ylab="Lethal equivalents",cex.lab=1.5)
for(i in 1:25){
  lines(1:100,lethalEqsFinal[i,901:1000],col=alpha("orange",alpha=0.2))
}
lethalEqsMeans <- colMeans(lethalEqsFinal[1:25,901:1000])
lines(1:100,lethalEqsMeans,lwd=4,col="darkorange")
par(xpd=TRUE)
text(x=-35,y=3.8,labels="B",cex=1.5,font=2)
par(xpd=FALSE)

############# small source population
for(i in 1:nrow(lethalEq1)){
  lines(1:100,lethalEq1[i,],col=alpha("blue",alpha=0.1))
}
lethalEq1Means <- colMeans(lethalEq1[,],na.rm=TRUE)
lines(1:100,lethalEq1Means,lwd=4,col=alpha("darkblue",alpha=0.8))


legend(x=30,y=2.75,legend=c("Immigration","No Immigration"),lty="solid",
       lwd=4,col=c(alpha("darkblue",alpha=0.8),"darkorange"),xjust=FALSE,yjust=FALSE,bty="n")

############################
######### drift load
###########################
plot(c(1,100),c(0,0.7),type="n",xlab="Generation",ylab="Drift load",cex.lab=1.5)
for(i in 1:25){
  lines(1:100,homLoadFinal[i,901:1000],col=alpha("orange",alpha=0.2))
}
homLoadMeans <- colMeans(homLoadFinal[1:25,901:1000])
lines(1:100,homLoadMeans,lwd=4,col="darkorange")
par(xpd=TRUE)
text(x=-35,y=0.77,labels="C",cex=1.5,font=2)
par(xpd=FALSE)

############# small source population
for(i in 1:nrow(genVar1)){
  lines(1:100,homLoad1[i,],col=alpha("blue",alpha=0.1))
}
homLoad1Means <- colMeans(homLoad1,na.rm=TRUE)
lines(1:100,homLoad1Means,lwd=4,col=alpha("darkblue",alpha=0.8))


############################
######### additive variance
############################
plot(c(1,100),c(0,10),type="n",xlab="Generation",ylab=expression(italic(""*V*"")[a]),cex.lab=1.5)
for(i in 1:25){
  lines(1:100,genVarFinal[i,901:1000],col=alpha("orange",alpha=0.2))
}
genVarMeans <- colMeans(genVarFinal[1:25,901:1000])
lines(1:100,genVarMeans,lwd=4,col="darkorange")
par(xpd=TRUE)
text(x=-35,y=10.9,labels="D",cex=1.5,font=2)
par(xpd=FALSE)


############# small source population
for(i in 1:nrow(genVar1)){
  lines(1:100,genVar1[i,],col=alpha("blue",alpha=0.1))
}
genVar1Means <- colMeans(genVar1[,],na.rm=TRUE)
lines(1:100,genVar1Means,lwd=4,col=alpha("darkblue",alpha=0.8))



