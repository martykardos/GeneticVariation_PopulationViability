# plot s distribution under assumptions of Kim et al. inference os the DFE
gammas <- -1*rgamma(1000000,shape=0.186,scale=0.071)
starts <- seq(-1,0-0.02,0.02)
ends <- starts + 0.02
ygammas <- rep(NA,length(starts))
for(i in 1:length(starts)){
  ygammas[i] <- sum(gammas >= starts[i] & gammas < ends[i])
}

ygammas2 <- ygammas/sum(ygammas)
plot(rowMeans(cbind(starts,ends)),ygammas2,type="n",xlab=expression(italic(""*s*"")),ylab="Proportion of Mutations",cex.lab=1.3)
for(i in 1:length(starts)){
  rect(xleft=starts[i],xright=ends[i],ybottom=0,ytop=ygammas2[i],col="gray")
}

