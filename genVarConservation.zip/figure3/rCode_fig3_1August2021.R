############################################################################
# commpare results from different source population sizes
############################################################################
setwd("~/Documents/dominance_genRescue/shortBtlnk_N100_popViab")
# collect population size
library(scales)

par(mfrow=c(3,2),mar=c(5,6,2,5))

# 2 generation bottleneck
NMat <- NULL
for(i in 1:10){
  NMat <- rbind(NMat,read.table(paste("N_K50_delMuts__2gens_",i,sep="")))
}
for(i in 1:ncol(NMat)){
  if(sum(is.na(NMat[,i]) > 0))NMat[is.na(NMat[,i]),i] <- 0
}
propExt <- colSums(NMat == 0)/nrow(NMat)

plot(c(0,120),c(0,1.2),type="n",xlab="",ylab=expression(paste(italic(""*N*"")," (Thousands)",sep="")),axes=FALSE,cex.lab=1.5)
axis(side=1,seq(0,120,20))
axis(side=2,seq(0,1.2,.200))
axis(side=4,seq(0,1.2,.300),labels=seq(0,1.2,.3)/1.2)


for(i in 1:nrow(NMat)){
  lines(1:121,NMat[i,80:200]/1000,col=alpha("darkgray",alpha=0.3))
}
lines(1:121,(1-propExt[80:200])*1.2,lwd=2)

par(xpd=TRUE)
text(x=-40,y=1.300,labels="A",cex=2)
par(xpd=FALSE)


# 2 generation bottleneck (small source population)
par(mar=c(5,2,2,9))
NMat <- NULL
for(i in 1:10){
  NMat <- rbind(NMat,read.table(paste("N_K50_delMuts_N0_500_2Gens_",i,sep="")))
}
for(i in 1:ncol(NMat)){
  if(sum(is.na(NMat[,i]) > 0))NMat[is.na(NMat[,i]),i] <- 0
}
propExt <- colSums(NMat == 0)/nrow(NMat)

plot(c(0,120),c(0,1.2),type="n",xlab="",ylab="",axes=FALSE,cex.lab=1.5)
axis(side=1,seq(0,120,20))
axis(side=2,seq(0,1.2,.200))
axis(side=4,seq(0,1.2,.300),labels=seq(0,1.2,.3)/1.2)

par(xpd=TRUE)
text(x=150,y=0.6,labels="Proportion Extant",srt=90,cex=1.5)
par(xpd=FALSE)

for(i in 1:nrow(NMat)){
  lines(1:121,NMat[i,80:200]/1000,col=alpha("darkgray",alpha=0.3))
}
lines(1:121,(1-propExt[80:200])*1.2,lwd=2)


# 10 generation bottleneck
par(mar=c(5,6,2,5))
NMat <- NULL
for(i in 1:10){
  NMat <- rbind(NMat,read.table(paste("N_K50_delMuts__10gens_",i,sep="")))
}
for(i in 1:ncol(NMat)){
  if(sum(is.na(NMat[,i]) > 0))NMat[is.na(NMat[,i]),i] <- 0
}
propExt <- colSums(NMat == 0)/nrow(NMat)

plot(c(0,120),c(0,1.2),type="n",xlab="",ylab=expression(paste(italic(""*N*"")," (Thousands)",sep="")),axes=FALSE,cex.lab=1.5)
axis(side=1,seq(0,120,20))
axis(side=2,seq(0,1.2,.200))
axis(side=4,seq(0,1.2,.300),labels=seq(0,1.2,.3)/1.2)


for(i in 1:nrow(NMat)){
  lines(1:121,NMat[i,80:200]/1000,col=alpha("darkgray",alpha=0.3))
}
lines(1:121,(1-propExt[80:200])*1.2,lwd=2)

par(xpd=TRUE)
text(x=-40,y=1.300,labels="B",cex=2)
par(xpd=FALSE)




# 10 generation bottleneck (small source population)
par(mar=c(5,2,2,9))
NMat <- NULL
for(i in 1:10){
  NMat <- rbind(NMat,read.table(paste("N_K50_delMuts_N0_500_10Gens_",i,sep="")))
}
for(i in 1:ncol(NMat)){
  if(sum(is.na(NMat[,i]) > 0))NMat[is.na(NMat[,i]),i] <- 0
}
propExt <- colSums(NMat == 0)/nrow(NMat)

plot(c(0,120),c(0,1.2),type="n",xlab="",ylab="",axes=FALSE,cex.lab=1.5)
axis(side=1,seq(0,120,20))
axis(side=2,seq(0,1.2,.200))
axis(side=4,seq(0,1.2,.300),labels=seq(0,1.2,.3)/1.2)

par(xpd=TRUE)
text(x=150,y=0.6,labels="Proportion Extant",srt=90,cex=1.5)
par(xpd=FALSE)

for(i in 1:nrow(NMat)){
  lines(1:121,NMat[i,80:200]/1000,col=alpha("darkgray",alpha=0.3))
}
lines(1:121,(1-propExt[80:200])*1.2,lwd=2)




# 50 generation bottleneck
par(mar=c(5,6,2,5))
NMat <- NULL
for(i in 1:10){
  NMat <- rbind(NMat,read.table(paste("N_K50_delMuts__50gens_",i,sep="")))
}
for(i in 1:ncol(NMat)){
  if(sum(is.na(NMat[,i]) > 0))NMat[is.na(NMat[,i]),i] <- 0
}
propExt <- colSums(NMat == 0)/nrow(NMat)

plot(c(0,120),c(0,1.2),type="n",xlab="Generation",ylab=expression(paste(italic(""*N*"")," (Thousands)",sep="")),axes=FALSE,cex.lab=1.5)
axis(side=1,seq(0,120,20))
axis(side=2,seq(0,1.2,.200))
axis(side=4,seq(0,1.2,.300),labels=seq(0,1.2,.3)/1.2)


for(i in 1:nrow(NMat)){
  lines(1:121,NMat[i,80:200]/1000,col=alpha("darkgray",alpha=0.3))
}
lines(1:121,(1-propExt[80:200])*1.2,lwd=2)

par(xpd=TRUE)
text(x=-40,y=1.300,labels="C",cex=2)
par(xpd=FALSE)




# 50 generation bottleneck (small source population)
par(mar=c(5,2,2,9))
NMat <- NULL
for(i in 1:10){
  NMat <- rbind(NMat,read.table(paste("N_K50_delMuts_N0_500_50Gens_",i,sep="")))
}
for(i in 1:ncol(NMat)){
  if(sum(is.na(NMat[,i]) > 0))NMat[is.na(NMat[,i]),i] <- 0
}
propExt <- colSums(NMat == 0)/nrow(NMat)

plot(c(0,120),c(0,1.2),type="n",xlab="Generation",ylab="",axes=FALSE,cex.lab=1.5)
axis(side=1,seq(0,120,20))
axis(side=2,seq(0,1.2,.200))
axis(side=4,seq(0,1.2,.300),labels=seq(0,1.2,.3)/1.2)

par(xpd=TRUE)
text(x=150,y=0.6,labels="Proportion Extant",srt=90,cex=1.5)
par(xpd=FALSE)

for(i in 1:nrow(NMat)){
  lines(1:121,NMat[i,80:200]/1000,col=alpha("darkgray",alpha=0.3))
}
lines(1:121,(1-propExt[80:200])*1.2,lwd=2)




