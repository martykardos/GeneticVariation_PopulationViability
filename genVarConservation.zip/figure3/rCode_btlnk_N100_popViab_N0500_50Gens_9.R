
setwd("~/Documents/dominance_genRescue/shortBtlnk_N100_popViab")
library(quantPop)
genVarMat <- NULL
genLoadMat <- NULL
piMat <- NULL
lethalEqMat <- NULL
homLoadMat <- NULL
NMat <- NULL


thisRepID <- "N0_500_50Gens_9"
carryCap1 <- 500
carryCap2 <- 100
btlnkTime <- 50
BURN <- 100
Gens <- 200
for(i in 1:5){
  tryCatch({
    logQuant_mut_delMut_ceiling(
      burnin=1,
      gens=Gens,
      genSize=10000000,
      chroms=10,
      phen0=0,
      phenOpt=rep(0,1100),
      c=50000000,
      mu=0,
      quantDom = FALSE,
      muOff=1100,
      minSize=-0.5,
      maxSize=0.5,
      N=c(rep(carryCap1,BURN),rep(carryCap1,Gens-BURN)),
      Ve=4,
      hardSelecGen=2,
      K=c(rep(carryCap1,BURN),rep(carryCap2,btlnkTime),rep(carryCap1,500)),
      lambda=2.5,
      f=4,
      delMutation=TRUE,
      delMu=6e-8,
      propLethal=0.05,
      delMuGammaShape=0.5,
      delMuGammaScale=0.1,
      neutMutation=TRUE,
      neutMu=0,
      Beta=13,
      importGenos=FALSE,
      importGenoIndivs=NULL,
      mutationTag=NULL,
      genoMat1Name=NULL,
      genoMat2Name=NULL,
      locusInfoName=NULL,
      genRescue=FALSE,
      rescueInGenos1=NULL,
      rescueInGenos2=NULL,
      rescueLocusInfo=NULL,
      rescueN=NULL,
      rescueGens=NULL)
    genVarMat <- rbind(genVarMat,addVar)
    genLoadMat <- rbind(genLoadMat,genLoad)
    piMat <- rbind(piMat,piVec)
    lethalEqMat <- rbind(lethalEqMat,lethalEqs)
    homLoadMat <- rbind(homLoadMat,homLoad)
    NMat <- rbind(NMat,NVec)
  }, error=function(e){})
}
write.table(homLoadMat,file=paste("homLoad_K50_delMuts_",thisRepID,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(lethalEqMat,file=paste("lethalEqs_K50_delMuts_",thisRepID,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(piMat,file=paste("pi_K50_delMuts_",thisRepID,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(genLoadMat,file=paste("genLoad_K50_delMuts_",thisRepID,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(genVarMat,file=paste("genVar_K50_delMuts_",thisRepID,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(NMat,file=paste("N_K50_delMuts_",thisRepID,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)

