setwd("/Users/martin.kardos/Documents/dominance_genRescue/Ne_genVars")

Nes <- c(rep(10,10),rep(25,10),rep(50,10),rep(100,10),rep(200,10),rep(400,10),rep(600,10),rep(800,10),rep(1000,10))
repVec <- rep(1:10,9)
piFiles <- paste("sourcePopPiVec_",Nes,"_",repVec,sep="")
addVarFiles <- paste("sourcePop_addVarVec_",Nes,"_",repVec,sep="")
genLoadFiles <- paste("sourcePop_genLoadVec_",Nes,"_",repVec,sep="")
homLoadFiles <- paste("sourcePop_homLoadVec_",Nes,"_",repVec,sep="")
polyInfoFiles <- paste("sourcePopPolyInfo_",Nes,"_",repVec,sep="")
freqFiles <- paste("sourcePop_freqs_",Nes,"_",repVec,sep="")
pi <- rep(NA,length(Nes))
addVar <- rep(NA,length(Nes))
genLoad <- rep(NA,length(Nes))
homLoad <- rep(NA,length(Nes))
LE <- rep(NA,length(Nes))

for(i in 1:length(Nes)){
  pi[i] <- read.table(piFiles[i])[1000,1]
  addVar[i] <- read.table(addVarFiles[i])[1000,1]
  genLoad[i] <- read.table(genLoadFiles[i])[1000,1]
  homLoad[i] <- read.table(homLoadFiles[i])[1000,1]

  freqs <- read.table(freqFiles[i])
  polyInfo <- read.table(polyInfoFiles[i])
  h <- 0.5*(exp(-13*as.numeric(polyInfo[,4])))
  LE[i] <- sum(freqs[,1]*as.numeric(polyInfo[,4])) - sum(freqs[,1]^2*as.numeric(polyInfo[,4]))-2*sum(freqs[,1]*(1-freqs[,1])*as.numeric(polyInfo[,4])*h)
}

homLoad[homLoad>1] <- 1

# figure
library(scales)
par(mfrow=c(3,1),mar=c(4,6,2,2),xpd=TRUE)
colVec <- c(rep("#f7fcfd", 10),rep("#e5f5f9",10),rep("#ccece6",10) ,rep("#99d8c9",10),rep("#66c2a4",10),rep("#41ae76",10),rep("#238b45",10),rep("#006d2c",10),rep("#00441b",10))
legCols <- c(rep("#f7fcfd", 1),rep("#e5f5f9",1),rep("#ccece6",1) ,rep("#99d8c9",1),rep("#66c2a4",1),rep("#41ae76",1),rep("#238b45",1),rep("#006d2c",1),rep("#00441b",1))


#LEs
plot(pi*10000,LE,xlab=expression(paste(pi," x 10"^5,sep="")),ylab="Lethal equivalents",cex.lab=1.5,col="black",bg=colVec,pch=21,cex=2)
text(x=-0.07,y=3.35,labels="A",cex=2)

# mutation load
plot(pi*10000,homLoad,ylim=c(0,1),xlab=expression(paste(pi," x 10"^5,sep="")),ylab="Drift load",cex.lab=1.5,col="black",bg=colVec,pch=21,cex=2)
#points(pi*10000,homLoad,cex.lab=1.5,col="black",bg=colVec,pch=24,cex=2)
legend(pch=21,col="black",pt.bg=legCols,title=expression(italic(""*N*"")[e]),
       legend=c("10","25","50","100","200","400","600","800","1000"),x=0.25,y=0.3,xjust=FALSE,yjust=FALSE)
text(x=-0.07,y=1.1,labels="B",cex=2)

# Va
plot(pi*10000,addVar,xlab=expression(paste(pi," x 10"^5,sep="")),ylab=expression(italic(""*V*"")[a]),
     cex.lab=1.5,col="black",bg=colVec,pch=21,cex=2)
text(x=-0.07,y=7.5,labels="C",cex=2)

