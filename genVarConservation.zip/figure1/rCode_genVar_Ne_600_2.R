library(quantPop)
reps <- 4
setNe <- 600
for(j in 1:length(setNe)){
  for(i in reps){
    #-----------------------------------------
    # simulate a big source population
    #-----------------------------------------
    logQuant_mut_delMut(burnin=20,
                        gens=1000,
                        genSize=10000000,
                        chroms=38,
                        phen0=0,
                        phenOpt=rep(0,5000),
                        c=5000000,
                        mu=0,
                        quantDom = FALSE,
                        muOff=5000,
                        minSize=-0.5,
                        maxSize=0.5,
                        N=rep(setNe[j],5000),
                        Ve=0.000000001,
                        hardSelecGen=5001,
                        K=1000,
                        lambda=2.5,
                        f=4,
                        delMutation=TRUE,
                        delMu=6e-8,
                        propLethal=0.05,
                        delMuGammaShape=0.5,
                        delMuGammaScale=0.1,
                        neutMutation=FALSE,
                        neutMu=0,
                        Beta=13,
                        importGenos=FALSE,
                        importGenoIndivs=NULL,
                        mutationTag=NULL,
                        genoMat1Name=NULL,
                        genoMat2Name=NULL,
                        locusInfoName=NULL,
                        genRescue=FALSE,
                        rescueInGenos1=NULL,
                        rescueInGenos2=NULL,
                        rescueLocusInfo=NULL,
                        rescueN=NULL,
                        rescueGens=NULL)
    write.table(lethalEqs,file=paste("sourcePop_lethalEqs_",setNe[j],"_",i,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
    write.table(fitMean,file=paste("sourcePop_fitMean_",setNe[j],"_",i,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
    outFreqVec <- outFreqs[match(polyInfo[,2],outFreqs[,1]),ncol(outFreqs)]
    write.table(outFreqVec,file=paste("sourcePop_freqs_",setNe[j],"_",i,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
    write.table(piVec,file=paste("sourcePopPiVec_",setNe[j],"_",i,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
    write.table(polyInfo,file=paste("sourcePopPolyInfo_",setNe[j],"_",i,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
    write.table(genoMat1,file=paste("sourcePop_gens1_",setNe[j],"_",i,sep=""),quote=FALSE,row.names=FALSE,col.names=TRUE)
    write.table(genoMat2,file=paste("sourcePop_gens2_",setNe[j],"_",i,sep=""),quote=FALSE,row.names=FALSE,col.names=TRUE)
    h2Vec <- addVar/phenVar
    write.table(h2Vec,file=paste("sourcePop_h2Vec_",setNe[j],"_",i,sep=""),quote=FALSE,row.names=FALSE,col.names=TRUE)
    write.table(numSegVec,file=paste("sourcePop_numSegVec_",setNe[j],"_",i,sep=""),quote=FALSE,row.names=FALSE,col.names=TRUE)
    write.table(genLoad,file=paste("sourcePop_genLoadVec_",setNe[j],"_",i,sep=""),quote=FALSE,row.names=FALSE,col.names=TRUE)
    write.table(homLoad,file=paste("sourcePop_homLoadVec_",setNe[j],"_",i,sep=""),quote=FALSE,row.names=FALSE,col.names=TRUE)
    write.table(addVar,file=paste("sourcePop_addVarVec_",setNe[j],"_",i,sep=""),quote=FALSE,row.names=FALSE,col.names=TRUE)
  }
}
