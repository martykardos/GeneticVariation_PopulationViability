setwd("/Users/martin.kardos/Documents/dominance_genRescue/Ne_genVars")
Nes <- c(rep(10,10),rep(25,10),rep(50,10),rep(100,10),rep(200,10),rep(400,10),rep(600,10),rep(800,10),rep(1000,10))
repVec <- rep(1:10,9)
piFiles <- paste("sourcePopPiVec_",Nes,"_",repVec,sep="")
addVarFiles <- paste("sourcePop_addVarVec_",Nes,"_",repVec,sep="")
genLoadFiles <- paste("sourcePop_genLoadVec_",Nes,"_",repVec,sep="")
homLoadFiles <- paste("sourcePop_homLoadVec_",Nes,"_",repVec,sep="")
polyInfoFiles <- paste("sourcePopPolyInfo_",Nes,"_",repVec,sep="")
genos1 <- paste("sourcePop_gens1_",Nes,"_",repVec,sep="")
genos2 <- paste("sourcePop_gens2_",Nes,"_",repVec,sep="")

for(i in 1:10){
  thisGeno1 <- read.table(genos1[i],header=TRUE) 
  thisGeno2 <- read.table(genos2[i],header=TRUE) 
  genos <- rbind(thisGeno1,thisGeno2)
  freqs <- NULL
  freqs <- cbind(freqs,colSums(genos)/nrow(genos))
  write.table(freqs,file=paste("sourcePop_freqs_",Nes[i],"_",repVec[i],sep=""),row.names=FALSE,col.names=FALSE,quote=FALSE)
}
