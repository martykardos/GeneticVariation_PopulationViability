#############################################################
# collect data from my mutation model first
#############################################################


setwd("/Users/martin.kardos/Documents/dominance_genRescue/Ne_genVars/rnd2")

Nes <- c(rep(25,10),rep(50,10),rep(100,10),rep(200,10),rep(400,10),rep(600,10),rep(800,10),rep(1000,10),rep(1500,10))
repVec <- rep(1:10,9)
piFiles <- paste("sourcePopPiVec_",Nes,"_",repVec,sep="")
addVarFiles <- paste("sourcePop_addVarVec_",Nes,"_",repVec,sep="")
genLoadFiles <- paste("sourcePop_genLoadVec_",Nes,"_",repVec,sep="")
homLoadFiles <- paste("sourcePop_homLoadVec_",Nes,"_",repVec,sep="")
gen1Files <- paste("sourcePop_homLoadVec_",Nes,"_",repVec,sep="")
polyInfoFiles <- paste("sourcePopPolyInfo_",Nes,"_",repVec,sep="")
freqFiles <- paste("sourcePop_freqs_",Nes,"_",repVec,sep="")
LeFiles <- paste("sourcePop_lethalEqs_",Nes,"_",repVec,sep="")
LE <- rep(NA,length(Nes))
for(i in 1:length(Nes)){
  LE[i] <- read.table(LeFiles[i])[1000,1]
}

LE_MK <- matrix(LE,nrow=9,ncol=10,byrow=TRUE)


##################################################
# get data from other mutation models
##################################################
setwd("~/Documents/dominance_genRescue/lethalEqs_TandH_Robinson_Kyriazis")
le_th <- NULL
le_rob <- NULL
le_kyr <- NULL

genLoad_th <- NULL
genLoad_rob <- NULL
genLoad_kyr <- NULL



ne <- c(25,50,100,200,400,600,800)

for(i in 1:7){
  thisLoad <- read.table(paste("genLoad_N",ne[i],sep=""))
  genLoad_th <- rbind(genLoad_th,thisLoad[1:10,500])
  genLoad_rob <- rbind(genLoad_rob,thisLoad[11:20,500])
  
  if(i < 8)genLoad_kyr <- rbind(genLoad_kyr,thisLoad[21:30,2000])
  if(i == 8)genLoad_kyr <- rbind(genLoad_kyr,thisLoad[21:30,1000])
  
  thisLE <- read.table(paste("lethalEqs_N",ne[i],sep=""))
  print(nrow(thisLE))
  print(ncol(thisLE)) 
  le_th <- rbind(le_th,thisLE[1:10,500])
  le_rob <- rbind(le_rob,thisLE[11:20,500])
  if(i < 8)le_kyr <- rbind(le_kyr,thisLE[21:30,2000])
  if(i == 8)le_kyr <- rbind(le_kyr,thisLE[21:30,1000])
}


# get estimates from simulations with N=1000
rob1000LE <- read.table("lethalEqs_rob_N1000")[1:10,]
rob1000genLoad <- read.table("genLoad_rob_N1000")[1:10,]
kyr1000LE <- NULL
kyr1000genLoad <- NULL

for(i in 1:10){
  kyr1000LE <- rbind(kyr1000LE, read.table(paste("lethalEqs_kyr_N1000_rep_",i,sep=""))[1:1000,1])
  kyr1000genLoad <- rbind(kyr1000genLoad, read.table(paste("genLoad_kyr_N1000_rep_",i,sep=""))[1:1000,1])
}

le_rob <- rbind(le_rob,rob1000LE[,1000])

le_kyr <- rbind(le_kyr,kyr1000LE[,1000])


# get estimates from simulations with N=1500
rob1500LE <- NULL

kyr1500LE <- NULL


for(i in 1:10){
  kyr1500LE <- rbind(kyr1000LE, read.table(paste("lethalEqs_kyr_N1500_rep_",i,sep=""))[1:1000,1])
  rob1500LE <- rbind(rob1000LE, read.table(paste("lethalEqs_rob_N1500_rep_",i,sep=""))[1:1000,1])
}
le_rob <- rbind(le_rob,rob1000LE[,1000])
le_kyr <- rbind(le_kyr,kyr1000LE[,1000])





##################################################
# plot lethal equivalents
##################################################
ne <- c(25,50,100,200,400,600,800,1000,1500)
plot(c(0.5,9.8),c(0,4.5),type="n",ylab="Lethal Equivalents",axes=FALSE,xlab=expression(italic(""*N*"")),cex.lab=1.3)
par(xpd=TRUE)
axis(side=1,at=seq(0.5,9.5,1),labels=rep("",length(seq(0.5,9.5,1))))
axis(side=2,at=seq(0,4.5,0.5))
text(x=seq(1,9,1),y=rep(-0.6,9),labels=ne,cex=1.2)

for(i in 1:9){
  rect(xleft=i-0.48,xright=i+0.48,ybottom=-0.1,ytop=4.5,col="gray95",border=NA)
}

for(i in 1:length(ne)){
  # Drosophila mutation rate
  leBar <- mean(LE_MK[i,],na.rm=TRUE)
  leSd <- sd(LE_MK[i,],na.rm=TRUE)
  points(x=i-0.2,y=leBar,pch=16,col="#33a02c",cex=1.5)
  arrows(x0=i-0.2,x1=i-0.2,y0=leBar-leSd,y1=leBar+leSd, length=0.075, angle=90, code=3,col="#33a02c")
  
  # T & H
  #leBar <- mean(le_th[i,],na.rm=TRUE)
  #leSd <- sd(le_th[i,],na.rm=TRUE)
  #points(x=i-0.05,y=leBar,pch=16,col="#b2df8a")
  #arrows(x0=i-0.05,x1=i-0.05,y0=leBar-leSd,y1=leBar+leSd, length=0.05, angle=90, code=3,col="#b2df8a")
  
  # Robinson
  leBar <- mean(le_rob[i,],na.rm=TRUE)
  leSd <- sd(le_rob[i,],na.rm=TRUE)
  points(x=i,y=leBar,pch=16,col="#1f78b4",cex=1.5)
  arrows(x0=i,x1=i,y0=leBar-leSd,y1=leBar+leSd, length=0.075, angle=90, code=3,col="#1f78b4")
  
  # kyriazis
  leBar <- mean(le_kyr[i,],na.rm=TRUE)
  leSd <- sd(le_kyr[i,],na.rm=TRUE)
  points(x=i+0.2,y=leBar,pch=16,col="#a6cee3",cex=1.5)
  arrows(x0=i+0.2,x1=i+0.2,y0=leBar-leSd,y1=leBar+leSd, length=0.075, angle=90, code=3,col="#a6cee3")
}


lines(c(0.5,9.5),c(3.1,3.1),lty="dashed",lwd=2)
legend(x=0.55,y=3.45,xjust=FALSE,yjust=FALSE,pch=16,title="Mutation Model",col=c("#33a02c","#a6cee3","#1f78b4"),legend=c("Fig. 1 simulations","Kyriazis et al. (2020)","Robinson et al (2018)"))

