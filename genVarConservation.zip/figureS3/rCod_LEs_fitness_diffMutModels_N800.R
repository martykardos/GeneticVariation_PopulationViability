setwd("~/Documents/dominance_genRescue/lethalEqs_TandH_Robinson_Kyriazis")
library(quantPop)
genVarMat <- matrix(NA,nrow=50,ncol=2050)
genLoadMat <- matrix(NA,nrow=50,ncol=2050)
piMat <- matrix(NA,nrow=50,ncol=2050)
lethalEqMat <- matrix(NA,nrow=50,ncol=2050)
homLoadMat <- matrix(NA,nrow=50,ncol=2050)
NMat <- matrix(NA,nrow=50,ncol=2050)


muVec <- c(0.013,0.028,0.462)
popSize <- 800
rowIter <- 1
for(i in 1:length(muVec)){
    for(j in 1:10){
      tryCatch({
      if(i < 3){
        logQuant_mut_delMut_kim(burnin=20,
                                gens=500,
                                genSize=10000000,
                                chroms=38,
                                phen0=0,
                                phenOpt=rep(0,5000),
                                c=500000,
                                mu=0,
                                quantDom = FALSE,
                                muOff=5000,
                                minSize=-0.5,
                                maxSize=0.5,
                                N=rep(popSize,5000),
                                Ve=0.000000001,
                                hardSelecGen=5001,
                                K=rep(popSize,5000),
                                lambda=2.5,
                                f=4,
                                delMutation=TRUE,
                                delMu=muVec[i]/(10000000*2),
                                propLethal=0,
                                delMuGammaShape=0.186,
                                delMuGammaScale=0.071,
                                neutMutation=TRUE,
                                neutMu=0,
                                Beta=NA,
                                importGenos=FALSE,
                                importGenoIndivs=NULL,
                                mutationTag=NULL,
                                genoMat1Name=NULL,
                                genoMat2Name=NULL,
                                locusInfoName=NULL,
                                genRescue=FALSE,
                                rescueInGenos1=NULL,
                                rescueInGenos2=NULL,
                                rescueLocusInfo=NULL,
                                rescueN=NULL,
                                rescueGens=NULL)
      }
        if(i == 3){
          logQuant_mut_delMut_kim(burnin=20,
                                  gens=2000,
                                  genSize=10000000,
                                  chroms=38,
                                  phen0=0,
                                  phenOpt=rep(0,5000),
                                  c=500000,
                                  mu=0,
                                  quantDom = FALSE,
                                  muOff=5000,
                                  minSize=-0.5,
                                  maxSize=0.5,
                                  N=rep(popSize,5000),
                                  Ve=0.000000001,
                                  hardSelecGen=5001,
                                  K=rep(popSize,5000),
                                  lambda=2.5,
                                  f=4,
                                  delMutation=TRUE,
                                  delMu=muVec[i]/(10000000*2),
                                  propLethal=0,
                                  delMuGammaShape=0.186,
                                  delMuGammaScale=0.071,
                                  neutMutation=TRUE,
                                  neutMu=0,
                                  Beta=NA,
                                  importGenos=FALSE,
                                  importGenoIndivs=NULL,
                                  mutationTag=NULL,
                                  genoMat1Name=NULL,
                                  genoMat2Name=NULL,
                                  locusInfoName=NULL,
                                  genRescue=FALSE,
                                  rescueInGenos1=NULL,
                                  rescueInGenos2=NULL,
                                  rescueLocusInfo=NULL,
                                  rescueN=NULL,
                                  rescueGens=NULL)
        }

      genVarMat[rowIter,1:length(addVar)] <- addVar
      genLoadMat[rowIter,1:length(genLoad)] <- genLoad
      piMat[rowIter,1:length(piVec)] <- piVec
      lethalEqMat[rowIter,1:length(lethalEqs)] <- lethalEqs
      homLoadMat[rowIter,1:length(homLoad)] <- homLoad
      NMat[rowIter,1:length(NVec)] <- NVec
      },error=function(e){})
      rowIter <- rowIter + 1
    }
 
}


write.table(homLoadMat,file=paste("homLoad_N",popSize,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(lethalEqMat,file=paste("lethalEqs_N",popSize,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(piMat,file=paste("pi_N",popSize,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(genLoadMat,file=paste("genLoad_N",popSize,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(genVarMat,file=paste("genVar_N",popSize,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(NMat,file=paste("N_N",popSize,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)

