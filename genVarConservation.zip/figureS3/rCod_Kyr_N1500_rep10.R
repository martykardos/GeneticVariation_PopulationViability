setwd("~/Documents/dominance_genRescue/lethalEqs_TandH_Robinson_Kyriazis")
library(quantPop)
genVarMat <- NULL
genLoadMat <- NULL
piMat <- NULL
lethalEqMat <- NULL
homLoadMat <- NULL
NMat <- NULL


muVec <- c(0.013,0.028,0.462)
popSize <- 1500
rep <- 10
i <- 3
      tryCatch({
      if(i < 3){
        logQuant_mut_delMut_kim(burnin=20,
                                gens=500,
                                genSize=10000000,
                                chroms=38,
                                phen0=0,
                                phenOpt=rep(0,5000),
                                c=500000,
                                mu=0,
                                quantDom = FALSE,
                                muOff=5000,
                                minSize=-0.5,
                                maxSize=0.5,
                                N=rep(popSize,5000),
                                Ve=0.000000001,
                                hardSelecGen=5001,
                                K=rep(popSize,5000),
                                lambda=2.5,
                                f=4,
                                delMutation=TRUE,
                                delMu=muVec[i]/(10000000*2),
                                propLethal=0,
                                delMuGammaShape=0.186,
                                delMuGammaScale=0.071,
                                neutMutation=TRUE,
                                neutMu=0,
                                Beta=NA,
                                importGenos=FALSE,
                                importGenoIndivs=NULL,
                                mutationTag=NULL,
                                genoMat1Name=NULL,
                                genoMat2Name=NULL,
                                locusInfoName=NULL,
                                genRescue=FALSE,
                                rescueInGenos1=NULL,
                                rescueInGenos2=NULL,
                                rescueLocusInfo=NULL,
                                rescueN=NULL,
                                rescueGens=NULL)
      }
        if(i == 3){
          logQuant_mut_delMut_kim(burnin=20,
                                  gens=1500,
                                  genSize=10000000,
                                  chroms=38,
                                  phen0=0,
                                  phenOpt=rep(0,5000),
                                  c=500000,
                                  mu=0,
                                  quantDom = FALSE,
                                  muOff=5000,
                                  minSize=-0.5,
                                  maxSize=0.5,
                                  N=rep(popSize,5000),
                                  Ve=0.000000001,
                                  hardSelecGen=5001,
                                  K=rep(popSize,5000),
                                  lambda=2.5,
                                  f=4,
                                  delMutation=TRUE,
                                  delMu=muVec[i]/(10000000*2),
                                  propLethal=0,
                                  delMuGammaShape=0.186,
                                  delMuGammaScale=0.071,
                                  neutMutation=TRUE,
                                  neutMu=0,
                                  Beta=NA,
                                  importGenos=FALSE,
                                  importGenoIndivs=NULL,
                                  mutationTag=NULL,
                                  genoMat1Name=NULL,
                                  genoMat2Name=NULL,
                                  locusInfoName=NULL,
                                  genRescue=FALSE,
                                  rescueInGenos1=NULL,
                                  rescueInGenos2=NULL,
                                  rescueLocusInfo=NULL,
                                  rescueN=NULL,
                                  rescueGens=NULL)
        }

      genVarMat <- rbind(genVarMat,addVar)
      genLoadMat <- genLoad
      piMat<- piVec
      lethalEqMat <- lethalEqs
      homLoadMat <- homLoad
      NMat <- NVec
      },error=function(e){})

write.table(homLoadMat,file=paste("homLoad_kyr_N",popSize,"_rep_",rep,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(lethalEqMat,file=paste("lethalEqs_kyr_N",popSize,"_rep_",rep,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(piMat,file=paste("pi_kyr_N",popSize,"_rep_",rep,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(genLoadMat,file=paste("genLoad_kyr_N",popSize,"_rep_",rep,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(genVarMat,file=paste("genVa_kyr_N",popSize,"_rep_",rep,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(NMat,file=paste("N_kyr_N",popSize,"_rep_",rep,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)

