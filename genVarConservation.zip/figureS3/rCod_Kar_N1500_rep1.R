#######################################################################
# test genetic rescue simulation workflow (h2 ~0.6)
#######################################################################
setwd("~/Documents/dominance_genRescue/Ne_genVars/hiMu")
library(quantPop)
genVarMat <- NULL
genLoadMat <- NULL
piMat <- NULL
lethalEqMat <- NULL
homLoadMat <- NULL
NMat <- NULL

setNe <- 1500
rep <- 1

logQuant_mut_delMut(burnin=1,
                    gens=1200,
                    genSize=10000000,
                    chroms=10,
                    phen0=0,
                    phenOpt=rep(0,1200),
                    c=6,
                    mu=7.35e-9,
                    quantDom = FALSE,
                    muOff=1200,
                    minSize=-0.5,
                    maxSize=0.5,
                    N=rep(setNe[j],1200),
                    Ve=4,
                    hardSelecGen=1201,
                    K=1500,
                    lambda=1.5,
                    f=4,
                    delMutation=TRUE,
                    delMu=6e-8,
                    propLethal=0.05,
                    delMuGammaShape=0.5,
                    delMuGammaScale=0.1,
                    neutMutation=TRUE,
                    neutMu=0,
                    Beta=13,
                    importGenos=FALSE,
                    importGenoIndivs=NULL,
                    mutationTag=NULL,
                    genoMat1Name=NULL,
                    genoMat2Name=NULL,
                    locusInfoName=NULL,
                    genRescue=FALSE,
                    rescueInGenos1=NULL,
                    rescueInGenos2=NULL,
                    rescueLocusInfo=NULL,
                    rescueN=NULL,
                    rescueGens=NULL)



      genVarMat <- rbind(genVarMat,addVar)
      genLoadMat <- genLoad
      piMat<- piVec
      lethalEqMat <- lethalEqs
      homLoadMat <- homLoad
      NMat <- NVec
  

write.table(homLoadMat,file=paste("homLoad_rob_N",popSize,"_rep_",rep,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(lethalEqMat,file=paste("lethalEqs_rob_N",popSize,"_rep_",rep,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(piMat,file=paste("pi_kyr_N",popSize,"_rep_",rep,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(genLoadMat,file=paste("genLoad_rob_N",popSize,"_rep_",rep,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(genVarMat,file=paste("genVa_rob_N",popSize,"_rep_",rep,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(NMat,file=paste("N_rob_N",popSize,"_rep_",rep,sep=""),quote=FALSE,row.names=FALSE,col.names=FALSE)

