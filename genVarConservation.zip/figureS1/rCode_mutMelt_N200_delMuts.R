
setwd("~/Documents/dominance_genRescue/mutationalMeltdown/N50/rnd2")
library(quantPop)
library(kinship2)
genVarMat <- NULL
genLoadMat <- NULL
piMat <- NULL
lethalEqMat <- NULL
homLoadMat <- NULL
NMat <- NULL
NeOut <- NULL


carryCap <- 200
N0 <- 200
BURN <- 1
Gens <- 200
meanFMat <- matrix(NA,nrow=50,ncol=Gens)
for(i in 9:50){
  tryCatch({
    logQuant_mut_delMut_ceiling(
      burnin=1,
      gens=Gens,
      genSize=10000000,
      chroms=10,
      phen0=0,
      phenOpt=rep(0,1000),
      c=500000,
      mu=0,
      quantDom = FALSE,
      muOff=1100,
      minSize=-0.5,
      maxSize=0.5,
      N=c(rep(N0,BURN),rep(50,Gens-BURN)),
      Ve=4,
      hardSelecGen=BURN+1,
      K=c(rep(N0,BURN),rep(carryCap,Gens-BURN)),
      lambda=2.5,
      f=4,
      delMutation=TRUE,
      delMu=6e-8,
      propLethal=0.05,
      delMuGammaShape=0.5,
      delMuGammaScale=0.1,
      neutMutation=TRUE,
      neutMu=0,
      Beta=13,
      importGenos=FALSE,
      importGenoIndivs=NULL,
      mutationTag=NULL,
      genoMat1Name=NULL,
      genoMat2Name=NULL,
      locusInfoName=NULL,
      genRescue=FALSE,
      rescueInGenos1=NULL,
      rescueInGenos2=NULL,
      rescueLocusInfo=NULL,
      rescueN=NULL,
      rescueGens=NULL,
      pedigree=TRUE)
    
    genVarMat <- rbind(genVarMat,addVar)
    genLoadMat <- rbind(genLoadMat,genLoad)
    piMat <- rbind(piMat,piVec)
    lethalEqMat <- rbind(lethalEqMat,lethalEqs)
    homLoadMat <- rbind(homLoadMat,homLoad)
    NMat <- rbind(NMat,NVec)
    
    # calculate pedigree inbreeding
    ped2 <- ped[ped[,1]<=50,]
    kins <- kinship(id=ped2[,2],dadid=ped2[,4],momid=ped2[,3])
    pedF <- rep(NA,nrow(ped2))
    for(j in 1:length(pedF)){
      pedF[j] <- kins[ped2[j,3],ped2[j,4]]
    }
    thisMeanF <- rep(0,length(unique(ped2[,1])))
    for(j in 2:length(thisMeanF)){
      thisMeanF [j] <- mean(pedF[ped2[,1] == j])
    }
    
    NeVec <- rep(NA,length(thisMeanF))
    deltaF <- rep(NA,length(thisMeanF))
    for(j in 2:length(NeVec)){
      deltaF [j]<- 1 - (1-thisMeanF[j])/(1-thisMeanF[j-1])
    }
    
    meanDeltaF <- mean(deltaF[1:50],na.rm=TRUE)
    estNe <- (1/meanDeltaF)/2
    predH <- rep(1,length(thisMeanF))
    for(j in 2:length(predH)){
      predH [j] <- predH[j-1] - (1/(2*estNe))*(predH[j-1])
    }
    
    plot(1:length(thisMeanF),thisMeanF)
    lines(1:length(predH),1-predH)
    
    NeOut <- c(NeOut,estNe)
  }, error=function(e){})
}

write.table(homLoadMat,file="homLoad_K200_delMuts",quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(lethalEqMat,file="lethalEqs_K200_delMuts",quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(piMat,file="pi_K200_delMuts",quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(genLoadMat,file="genLoad_K200_delMuts",quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(genVarMat,file="genVar_K200_delMuts",quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(NMat,file="N_K200_delMuts",quote=FALSE,row.names=FALSE,col.names=FALSE)
write.table(NeOut,file="Ne_K200_delMuts",quote=FALSE,row.names=FALSE,col.names=FALSE)






