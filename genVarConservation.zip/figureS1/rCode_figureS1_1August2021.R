setwd("/Users/martin.kardos/Documents/dominance_genRescue/mutationalMeltdown/N50")

homLoad_K50_Del <- read.table("homLoad_K50_delMuts",header=FALSE)[1:50,]
lethalEqs_K50_Del <- read.table("lethalEqs_K50_delMuts",header=FALSE)[1:50,]
pi_K50_Del <- read.table("pi_K50_delMuts",header=FALSE)[1:50,]
N_K50_Del <- read.table("N_K50_delMuts",header=FALSE)[1:50,]

homLoad_K100_Del <- read.table("homLoad_K100_delMuts",header=FALSE)[1:50,]
lethalEqs_K100_Del <- read.table("lethalEqs_K100_delMuts",header=FALSE)[1:50,]
pi_K100_Del <- read.table("pi_K100_delMuts",header=FALSE)[1:50,]
N_K100_Del <- as.matrix(read.table("N_K100_delMuts",header=FALSE))[1:50,]


homLoad_K200_Del <- read.table("homLoad_K200_delMuts",header=FALSE)[1:50,]
lethalEqs_K200_Del <- read.table("lethalEqs_K200_delMuts",header=FALSE)[1:50,]
pi_K200_Del <- read.table("pi_K200_delMuts",header=FALSE)[1:50,]
N_K200_Del <- as.matrix(read.table("N_K200_delMuts",header=FALSE))[1:50,]

for(i in 1:50){
  if(sum(is.na(N_K50_Del[i,]) > 0)) N_K50_Del[i,which(is.na(N_K50_Del[i,]))] <- 0
  if(sum(is.na(N_K100_Del[i,]) > 0)) N_K100_Del[i,which(is.na(N_K100_Del[i,]))] <- 0
  if(sum(is.na(N_K200_Del[i,]) > 0)) N_K200_Del[i,which(is.na(N_K200_Del[i,]))] <- 0
}


par(mfrow=c(2,3),mar=c(2,5,4,4),xpd=FALSE)
library(scales)
#------------------
# K = 50
#------------------
plot(c(0,100),c(0,100),type="n",axes=FALSE,ylab=expression(italic(""*N*"")),
     cex.lab=1.5,xlab="",main=expression(paste(italic(""*K*"")," = 50",sep="" )),cex.main=1.5)
for(i in 1:nrow(N_K50_Del)){
  lines(1:100,N_K50_Del[i,1:100],col=alpha("darkgray",alpha=0.5))
}
propExt <- rep(NA,100)
for(i in 1:100){
  propExt[i] <- sum(N_K50_Del[,i] == 0)/nrow(N_K50_Del)
}
lines(1:100,100-propExt*100,lwd=3)
axis(side=2,at=seq(0,100,25))
axis(side=1,at=seq(0,100,20))
axis(side=4,at=seq(0,100,20),labels=FALSE)
par(xpd=TRUE)
text(x=rep(115,6),y=seq(0,100,20),labels=seq(0,1,0.2),srt=270)
text(x=-35,y=120,labels="A",cex=2)
par(xpd=FALSE)

lines(c(0,100),c(50,50),lty="dashed")

#------------------
# K = 100
#------------------
plot(c(0,100),c(0,175),type="n",axes=FALSE,ylab="",cex.lab=1.3,xlab="",
     main=expression(paste(italic(""*K*"")," = 100",sep="" )),cex.main=1.5)
for(i in 1:nrow(N_K100_Del)){
  lines(1:100,N_K100_Del[i,1:100],col=alpha("darkgray",alpha=0.5))
}
propExt <- rep(NA,100)
for(i in 1:100){
  propExt[i] <- sum(N_K100_Del[,i] == 0)/nrow(N_K100_Del)
}
lines(1:100,175-propExt*175,lwd=3,col="black")
axis(side=2,at=seq(0,175,25))
axis(side=1,at=seq(0,100,20))
axis(side=4,at=seq(0,175,35),labels=FALSE)
par(xpd=TRUE)
text(x=rep(115,6),y=seq(0,175,35),labels=seq(0,1,0.2),srt=270)
text(x=-35,y=210,labels="B",cex=2)
par(xpd=FALSE)
lines(c(0,100),c(100,100),lty="dashed")

#------------------
# K = 200
#------------------
plot(c(0,100),c(50,300),type="n",axes=FALSE,ylab="",cex.lab=1.3,xlab="",
     main=expression(paste(italic(""*K*"")," = 200",sep="" )),cex.main=1.5)
for(i in 1:nrow(N_K200_Del)){
  lines(1:100,N_K200_Del[i,1:100],col=alpha("darkgray",alpha=0.5))
}
propExt <- rep(NA,100)
for(i in 1:100){
  propExt[i] <- sum(N_K200_Del[,i] == 0)/nrow(N_K200_Del)
}
lines(1:100,60 + (240-propExt*240),lwd=3,col="black")
axis(side=2,at=seq(50,300,50))
axis(side=1,at=seq(0,100,20))
axis(side=4,at=seq(50,300,50),labels=FALSE)
par(xpd=TRUE)
text(x=125,y=180,labels="Proportion extant",srt=90,cex=1.3)
text(x=rep(115,6),y=seq(60,300,48),labels=seq(0,1,0.2),srt=270)
text(x=-35,y=350,labels="C",cex=2)
par(xpd=FALSE)
lines(c(0,100),c(200,200),lty="dashed")


##############################
# plot homozygous load
##############################

par(mar=c(4,5,2,4))
#------------------
# K = 50
#------------------
plot(c(0,100),c(0,0.6),type="n",axes=FALSE,ylab="Drift load",cex.lab=1.5,xlab="Generation")
for(i in 1:nrow(N_K50_Del)){
  lines(1:100,homLoad_K50_Del[i,1:100],col=alpha("darkgray",alpha=0.5))
}


meanLoad <- colMeans(homLoad_K50_Del,na.rm=TRUE)
lines(1:100,meanLoad[1:100],lwd=3,col="black")
axis(side=2,at=seq(0,0.6,0.1))
axis(side=1,at=seq(0,100,20))

#------------------
# K = 100
#------------------
plot(c(0,100),c(0,0.6),type="n",axes=FALSE,ylab="",cex.lab=1.5,xlab="Generation")
for(i in 1:nrow(homLoad_K100_Del)){
  lines(1:100,homLoad_K100_Del[i,1:100],col=alpha("darkgray",alpha=0.5))
}

meanLoad <- colMeans(homLoad_K100_Del,na.rm=TRUE)
lines(1:100,meanLoad[1:100],lwd=3,col="black")
axis(side=2,at=seq(0,0.6,0.1))
axis(side=1,at=seq(0,100,20))


#------------------
# K = 200
#------------------
plot(c(0,100),c(0,0.6),type="n",axes=FALSE,ylab="",cex.lab=1.5,xlab="Generation")
for(i in 1:nrow(homLoad_K200_Del)){
  lines(1:100,homLoad_K200_Del[i,1:100],col=alpha("darkgray",alpha=0.5))
}

meanLoad <- colMeans(homLoad_K200_Del,na.rm=TRUE)
lines(1:100,meanLoad[1:100],lwd=3,col="black")
axis(side=2,at=seq(0,0.6,0.1))
axis(side=1,at=seq(0,100,20))

